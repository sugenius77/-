import ModalContainer from "./ModalContainer";

export default ModalContainer;